# HoriCraft Asset Catalog

BOOTH Library Manager の保存済み商品を Unity Editor で探し、取り込んだアセットと BOOTH 商品ページを結び付ける Windows 向け Editor 拡張です。BOOTH Library Manager とは別の非公式ツールです。

この `1.0.0-candidate.3` は**有料版の公開テスト提供分**です。解除キーの設定を反映済みです。購入者が受け取る解除キーを入力して有効化します。旧 `0.3.0-preview.1`～`.5` のMIT許諾は維持されます。

## 動作環境

- Windows、Unity 2022.3 以降
- BOOTH Library Manager の `data.db` と、設定済みのダウンロード保存先
- BOOTH の商品画像を表示する場合はインターネット接続

## 使い方

1. パッケージを Unity プロジェクトへ追加します。公開VPMからの追加方法は配布ページを参照してください。
2. Unity上部の `HoriCraft > Asset Catalog` を開きます。`Window > HoriCraft > Asset Catalog` からも開けます。購入時に受け取った解除キーを貼り付けて有効化します。有効化情報はPC内に保存され、解除キーそのものは保存しません。未有効化時はDB参照・取り込み照合・画像保存・タグ/リンク操作などの機能を使えません。
3. 有効化後は通常、BOOTH Library Managerの管理データを自動で読み込みます。必要な場合は右上の「設定」から「BOOTH Library Managerのデータ」を選び直します。「設定」からこのPCの有効化情報も削除できます。削除してもタグ・リンク・画像は残ります。
4. 商品名・ショップ名・商品IDで検索できます。「フィルタ」ではカテゴリとサブカテゴリを別々に選べます。サブカテゴリは選択したカテゴリに連動し、カテゴリを変更すると解除されます。年齢制限は「全年齢のみ／R-18商品のみ」を選び、選択中のボタンを再度押すと解除できます。タグは検索して複数選択できます。適用件数とタグ選択数を表示し、「フィルタをクリア」で条件をまとめて解除します（商品検索の入力は残します）。ショップ・手動リスト・タグのAND/OR条件は「ショップ・リスト・タグの条件」から選べます。登録済み／未登録は、このプロジェクトへの紐づけの有無を表します。
5. BOOTH Library Manager の保存先にある `.unitypackage` をエクスプローラーでダブルクリックするか、Unity 標準の `Assets > Import Package > Custom Package...` から取り込みます。どちらも Unity 標準の取り込み画面を使います。
6. 取り込み完了後、同名の `.unitypackage` と Unity に取り込まれたアセットの GUID を照合します。一意に一致した場合は自動で紐づけ、商品画像も `Assets/HoriCraft/BoothLibraryUnity/Thumbnails/<商品ID>.png` に自動保存します。自動確定できない場合は一覧付近の「商品との紐づけを確認」で理由を読み、候補を選びます。Assetsへの取り込み自体は完了しています。
7. 「エクスプローラーで開く」でダウンロード済みの商品フォルダーの中身を直接開きます。「Assetsで開く」では紐づいた位置をUnityのProject欄で表示します。複数ある場合は移動先を選べます。
8. 以前からAssetsにある商品をまとめて探す場合は「設定」→「導入済みAssetsを一括連携」で走査・候補確認・選択適用を行います。フォルダー名だけで自動確定せず、共有GUIDや既存の手動リンクは変更しません。商品が見つかってもフォルダー全体を商品専用とは判定しません。前回の一括連携は、後から手動変更していないリンクだけ取り消せます。画像は取り消しで削除しません。
9. 手動でフォルダーを登録する場合は、Projectで商品フォルダーを選び、商品詳細の「選択フォルダーをこの商品に登録」を押します。商品画像の保存中・保存済み・失敗は商品詳細に表示します。通信に失敗しても紐づけは維持され、再試行できます。既存画像は上書きしません。

## BOOTH Library Managerのデータを選ぶ

選ぶファイルは、BOOTH Library Managerが作る管理ファイル `data.db` です。標準の場所は次の通りです。

```text
%APPDATA%\pm.booth.library-manager\data.db
```

1. Asset Catalog右上の「設定」から「BOOTH Library Managerのデータ」を押します。DBが見つからない場合は、この案内が自動で表示されます。
2. 標準の場所なら「標準の場所を使う」を押します。
3. 手動で選ぶ場合は「data.db を選ぶ…」を押し、BOOTH Library Managerの `data.db` を選択します。「場所をコピー」で標準パスをコピーし、ファイル選択画面のファイル名欄へ貼り付けても開けます。

BOOTH Library Managerをまだ使っていない場合は、一度BOOTH Library Managerを起動して商品を登録してください。商品ファイルの保存先はDBから読み取ります。選んだDBは読み取り専用で開き、正常に読み込めた場合だけ接続先として保存します。

English: Choose BOOTH Library Manager's `data.db` catalog, normally at `%APPDATA%\pm.booth.library-manager\data.db`. Use **Settings → BOOTH Library Manager data → Use default catalog**, or **Choose data.db…** for another location. The catalog is opened read-only; a failed selection does not replace the saved connection.

## データの参照先

| 内容 | 参照先 | 書き込み |
| --- | --- | --- |
| 商品名、ID、BOOTH Library Managerタグ、手動リスト、画像URL、商品保存先 | `%APPDATA%/pm.booth.library-manager/data.db` | しません |
| Unity 内で追加したタグ | `%APPDATA%/HoriCraft/BoothLibraryUnity/unity-tags.json` | します |
| 商品画像キャッシュ | `%LOCALAPPDATA%/HoriCraft/BoothLibraryUnity/Thumbnails/` | します |
| 取り込みアセットと商品IDの対応 | `<Unity project>/UserSettings/HoriCraftBoothLibrary/asset-links.json` | します |
| 手動フォルダーの対応 | `<Unity project>/UserSettings/HoriCraftBoothLibrary/folder-links.json` | します |
| 画像の自動保存状況・再開待ち | `<Unity project>/UserSettings/HoriCraftBoothLibrary/import-setup.json` | します |
| 一括連携の前回操作記録 | `<Unity project>/UserSettings/HoriCraftBoothLibrary/bulk-link-last-run.json` | します |
| 有効化情報のハッシュ | このPCの `EditorPrefs` にあるAsset Catalog専用キー | します |

商品ページはデータベースの商品IDから `https://booth.pm/ja/items/<商品ID>` を組み立てます。商品画像は DB 内の `thumbnail_url` から取得します。BOOTH Library Manager の DB やダウンロード済み商品自体には変更を加えません。

## 現在の範囲

- BOOTH Library Manager のタグと手動リストは表示・検索できます。BOOTH Library Manager 側へのタグ書き戻しはありません。Unity タグは独立したファイルに保存します。
- BOOTH Library Manager のスマートリストは現在読み取りません。
- 取り込み後の紐づけは、同じファイル名の `.unitypackage` と GUID の一致を使います。取り込む項目を変更した場合や、元パッケージが保存先にない場合は自動判定できないことがあります。
- Unity Projectのフォルダー画像表示はEditor上の重ね描きです。商品確定後は画像のPNGもAssetsへ自動保存します。商品一覧を眺めるだけではAssetsに画像を作りません。既存画像がある場合は保護し、画像として読めない場合は再試行の案内を表示します。
- `UserSettings` の対応表は通常 Git で共有されません。別PCや別プロジェクトで同じ対応を使う場合は、このファイルを別途移してください。
- プロジェクトへ書き出した商品画像を第三者に再配布する場合は、画像の利用条件を確認してください。

## License

この版の利用条件と施行日は [LICENSE.md](LICENSE.md) を確認してください。旧preview.1～.5のMIT許諾は維持されます。BOOTH Library Manager のデータ、BOOTH の商品画像、ダウンロード商品は本パッケージに含めません。

---

English summary: This paid candidate requires offline activation before reading the catalog or using its tools. The top right contains Refresh and Settings. Imports can link assets and save product PNGs automatically; unclear matches appear as product-link reviews near the list. Settings also opens the existing-Assets bulk scan, which previews candidates before linking and can undo unchanged links from the last run. Existing files, manual links, and Unity tags are preserved. Smart lists and tag write-back are not supported.
