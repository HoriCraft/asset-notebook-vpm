# Changelog

## 1.0.0-candidate.6 — テスト版 / Test version

- 表示名を「アセットノート / Asset Notebook」へ変更。package ID、assembly、namespace、保存先、既存meta、解除キー方式を維持。
- ワンボタンの自動連携、進捗・中止・続行・失敗理由・再試行・前回分の取消を追加。画像保存queueの失敗時に状態を先行させないよう修正。
- 固定の画像・商品名ヘッダーと下部スクロール、フィルタの重ね表示、部分一致タグ入力、日英の明示切替と選択保持、Assets移動先の集約を追加。
- 共通の版表示、manifestとDLLの版照合、最小限の問い合わせ情報コピーを追加。
- BOOTH Library Managerデータ選択を設定へまとめ、取り込み商品の紐づけ確認に理由と操作の説明を表示。

English: renamed the visible product, added one-button automatic linking with progress, stop/continue/retry/undo, improved queue failure handling, fixed detail headers and filters, persistent language selection, grouped Assets navigation, package-version checks and minimal support information. Existing identities, paths and activation configuration remain unchanged. This is a test version.

Earlier public candidates remain immutable. Their original changelogs and licenses are retained in the corresponding packages. The MIT grants for preview.1–.5 remain unchanged.