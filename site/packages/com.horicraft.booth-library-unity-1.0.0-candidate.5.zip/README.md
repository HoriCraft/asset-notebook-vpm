# HoriCraft Asset Catalog

BOOTH Library Manager の保存済み商品を Unity Editor で探し、取り込んだアセットと BOOTH 商品ページを結び付ける Windows 向け Editor 拡張です。BOOTH Library Manager とは別の非公式ツールです。

この `1.0.0-candidate.5` は**有料版の公開テスト提供分**です。一括連携の分割走査・再開・失敗理由の表示と分割反映を追加しました。購入者が受け取る解除キーで有効化します。旧 `0.3.0-preview.1`～`.5` のMIT許諾は維持されます。

## 動作環境

- Windows、Unity 2022.3 以降
- BOOTH Library Manager の `data.db` と、設定済みのダウンロード保存先
- BOOTH の商品画像を表示する場合はインターネット接続

表示言語はOSに合わせ、日本語の場合は日本語、それ以外は英語です。商品名・購入ファイル名・タグなどのユーザーデータは翻訳しません。既存の日本語メニューは維持し、フォルダー設定には英語のメニュー入口も用意しています。一括連携は英語画面の Settings → Link existing Assets in bulk から開けます。

## 使い方

1. VCC / ALCOMでプレリリース版を表示し、公開VPMから `1.0.0-candidate.5` をUnityプロジェクトへ追加・更新します。導入方法は配布ページを参照してください。
2. Unity上部の `HoriCraft > Asset Catalog` を開きます。`Window > HoriCraft > Asset Catalog` からも開けます。購入時のZIPを展開して `START_HERE.html` の「解除キーをコピー」を押し、Unityの「解除キーを貼り付け」で有効化します。手入力も選べます。有効化情報は同じPCのUnityプロジェクトで共有され、解除キーそのものは保存しません。別PCでは解除キーを再入力します。未有効化時はDB参照・取り込み照合・画像保存・タグ/リンク操作などの機能を使えません。
3. 有効化後は通常、BOOTH Library Managerの管理データを自動で読み込みます。必要な場合は右上の「設定」から「BOOTH Library Managerのデータ」を選び直します。「設定」→「ライセンス情報」からこのPCの有効化情報も削除できます。削除すると同じPCのほかのUnityプロジェクトでも再入力が必要です。タグ・リンク・画像は残ります。
4. 商品名・ショップ名・商品IDで検索できます。「フィルタ」ではカテゴリとサブカテゴリを別々に選べます。サブカテゴリは選択したカテゴリに連動し、カテゴリを変更すると解除されます。年齢制限は「全年齢のみ／R-18商品のみ」を選び、選択中のボタンを再度押すと解除できます。タグは検索して複数選択できます。適用件数とタグ選択数を表示し、「フィルタをクリア」で条件をまとめて解除します（商品検索の入力は残します）。ショップ・手動リスト・タグのAND/OR条件は「ショップ・リスト・タグの条件」から選べます。登録済み／未登録は、このプロジェクトへの紐づけの有無を表します。
5. BOOTH Library Manager の保存先にある `.unitypackage` をエクスプローラーでダブルクリックするか、Unity 標準の `Assets > Import Package > Custom Package...` から取り込みます。どちらも Unity 標準の取り込み画面を使います。
6. 取り込み完了後、同名の `.unitypackage` と Unity に取り込まれたアセットの GUID を照合します。一意に一致した場合は自動で紐づけ、商品画像も `Assets/HoriCraft/BoothLibraryUnity/Thumbnails/<商品ID>.png` に自動保存します。自動確定できない場合は一覧付近の「商品との紐づけを確認」で理由を読み、候補を選びます。Assetsへの取り込み自体は完了しています。
7. 「エクスプローラーで開く」でダウンロード済みの商品フォルダーの中身を直接開きます。「Assetsで開く」では紐づいた位置をUnityのProject欄で表示します。複数ある場合は移動先を選べます。
8. 以前からAssetsにある商品をまとめて探す場合は「設定」→「導入済みAssetsを一括連携」を開きます。現在の保存先はBOOTH Library ManagerのDBから読みます。途中で保存先を変えた場合は「旧・追加の保存先を指定」で、旧保存先の `b商品ID` フォルダーが並ぶ場所も追加し、「旧・現在の保存先をすべて指定しました」を確認します。追加保存先はこのプロジェクトのUserSettingsに保存し、一括走査だけに使います。指定された場所だけを調べ、ドライブ全体は探索しません。
   初回は指定先の全packageの確認が必要です。「一度に読むpackage」を選び、「候補を調べる」→「次の分を調べる」で小分けに調べます。中止しても、正常に読めた結果はこのプロジェクトのUserSettingsに残り、次回再利用します。変更されたpackageは読み直します。固有判定は指定された保存先の範囲です。未調査・読取り失敗・保存先の未接続がある間は確定できないため連携できません。「読めなかったファイルと理由」で商品・場所・原因を確認し、外付けの接続やアクセス権、元packageを確認した後に「失敗したpackageを再試行」を押してください。元packageは自動で削除・書換え・除外しません。
9. 走査完了後は「一度に連携する商品」を選び、候補を選んで「選択した候補を連携」を繰り返します。同じ候補一覧の分割分は、一つの操作としてまとめて取り消せます。全件調査後にもう一度走査した場合や画面を開き直した場合は新しい操作になり、最初の反映時に前回の取消記録を切り替えるか確認します。前回のリンク自体は残ります。フォルダー名だけで自動確定せず、共有GUIDや既存の手動リンクは変更しません。取り消すのはその操作で追加し、その後に手動変更していないリンクだけで、画像は削除しません。再利用キャッシュは再取得できる読取り結果であり、商品との連携データとは別です。
10. 手動でフォルダーを登録する場合は、Projectで商品フォルダーを選び、商品詳細の「選択フォルダーをこの商品に登録」を押します。商品画像の保存中・保存済み・失敗は商品詳細に表示します。通信に失敗しても紐づけは維持され、再試行できます。既存画像は上書きしません。
11. 商品詳細の「表示画像を差し替える」からPNG/JPEGを選ぶと、その画像のコピーをこのプロジェクトの `UserSettings/HoriCraftBoothLibrary/CustomThumbnails/` に商品ID別で保存します。一覧・詳細・Projectのフォルダー表示ではこれを優先します。「標準画像に戻す」で差し替えコピーだけを削除します。BOOTH Library ManagerのDB、BOOTH画像キャッシュ、Assetsに保存済みの商品画像、購入アセットは変更しません。入力は20MB以下、縦横4096px以下かつ1600万画素以下です。

## BOOTH Library Managerのデータを選ぶ

選ぶファイルは、BOOTH Library Managerが作る管理ファイル `data.db` です。標準の場所は次の通りです。

```text
%APPDATA%\pm.booth.library-manager\data.db
```

1. Asset Catalog右上の「設定」から「BOOTH Library Managerのデータ」を押します。DBが見つからない場合は、この案内が自動で表示されます。
2. 標準の場所なら「標準の場所を使う」を押します。
3. 手動で選ぶ場合は「data.db を選ぶ…」を押し、BOOTH Library Managerの `data.db` を選択します。「場所をコピー」で標準パスをコピーし、ファイル選択画面のファイル名欄へ貼り付けても開けます。

BOOTH Library Managerをまだ使っていない場合は、一度BOOTH Library Managerを起動して商品を登録してください。商品ファイルの保存先はDBから読み取ります。選んだDBは読み取り専用で開き、正常に読み込めた場合だけ接続先として保存します。

English: Choose BOOTH Library Manager's `data.db` catalog, normally at `%APPDATA%\pm.booth.library-manager\data.db`. Use **Settings → BOOTH Library Manager data → Use default catalog**, or **Choose data.db…** for another location. The catalog is opened read-only; a failed selection does not replace the saved connection.

## データの参照先

| 内容 | 参照先 | 書き込み |
| --- | --- | --- |
| 商品名、ID、BOOTH Library Managerタグ、手動リスト、画像URL、商品保存先 | `%APPDATA%/pm.booth.library-manager/data.db` | しません |
| Unity 内で追加したタグ | `%APPDATA%/HoriCraft/BoothLibraryUnity/unity-tags.json` | します |
| 商品画像キャッシュ | `%LOCALAPPDATA%/HoriCraft/BoothLibraryUnity/Thumbnails/` | します |
| 取り込みアセットと商品IDの対応 | `<Unity project>/UserSettings/HoriCraftBoothLibrary/asset-links.json` | します |
| 手動フォルダーの対応 | `<Unity project>/UserSettings/HoriCraftBoothLibrary/folder-links.json` | します |
| 画像の自動保存状況・再開待ち | `<Unity project>/UserSettings/HoriCraftBoothLibrary/import-setup.json` | します |
| 一括連携の前回操作記録 | `<Unity project>/UserSettings/HoriCraftBoothLibrary/bulk-link-last-run.json` | します |
| 有効化情報のハッシュ | このPCの `EditorPrefs` にあるAsset Catalog専用キー | します |

商品ページはデータベースの商品IDから `https://booth.pm/ja/items/<商品ID>` を組み立てます。商品画像は DB 内の `thumbnail_url` から取得します。BOOTH Library Manager の DB やダウンロード済み商品自体には変更を加えません。

## 現在の範囲

- BOOTH Library Manager のタグと手動リストは表示・検索できます。BOOTH Library Manager 側へのタグ書き戻しはありません。Unity タグは独立したファイルに保存します。
- BOOTH Library Manager のスマートリストは現在読み取りません。
- 取り込み後の紐づけは、同じファイル名の `.unitypackage` と GUID の一致を使います。取り込む項目を変更した場合や、元パッケージが保存先にない場合は自動判定できないことがあります。
- Unity Projectのフォルダー画像表示はEditor上の重ね描きです。商品確定後は画像のPNGもAssetsへ自動保存します。商品一覧を眺めるだけではAssetsに画像を作りません。既存画像がある場合は保護し、画像として読めない場合は再試行の案内を表示します。
- `UserSettings` の対応表は通常 Git で共有されません。別PCや別プロジェクトで同じ対応を使う場合は、このファイルを別途移してください。
- プロジェクトへ書き出した商品画像を第三者に再配布する場合は、画像の利用条件を確認してください。

## License

この版の利用条件と施行日は [LICENSE.md](LICENSE.md) を確認してください。旧preview.1～.5のMIT許諾は維持されます。BOOTH Library Manager のデータ、BOOTH の商品画像、ダウンロード商品は本パッケージに含めません。

---

English summary: This paid candidate requires offline activation before reading the catalog or using its tools. Activation is shared across Unity projects on the same PC; another PC requires the purchase key again. The top right contains Refresh and Settings. Imports can link assets and save product PNGs automatically; unclear matches appear as product-link reviews near the list. Settings also opens the existing-Assets bulk scan, which previews candidates before linking and can undo unchanged links from the last run. Existing files, manual links, and Unity tags are preserved. Smart lists and tag write-back are not supported.
