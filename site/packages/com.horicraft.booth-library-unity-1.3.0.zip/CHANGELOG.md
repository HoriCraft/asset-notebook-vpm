# 更新履歴 / Changelog

## 1.3.0

1.0.2からの変更です。

- 新しいプロジェクトでも保存済みマイリストのインポートを先に開始でき、同じPCで調査済みのパッケージ情報を再利用します。

- 商品内のunitypackageを検索・選択し、表示した順で直接インポートできるようにしました。個別のUnity確認画面も選べます。ExplorerでREADMEやZIPを開く操作も残しました。
- PCの同じOSユーザーで共通のマイリスト・お気に入りを追加しました。商品とファイル選択・順番を記憶し、現在のプロジェクトへまとめてインポートできます。
- 新しい選択では、選んだMaterial用パッケージを同じ商品内で先にします。明示した順番と既存の保存順は維持します。
- カタログ／リスト行を左ナビの既存マイリストへドラッグして追加できます。重複追加やお気に入りの意図しない解除を防ぎ、狭幅ではボタン操作を維持しました。
- インポートの進行、後続の一時停止・中止、再開、失敗や結果未記録からの確認を整理しました。待機・完了記録はプロジェクトごとに保存し、再起動後は自動再開しません。
- 画面の文言と狭幅表示を見直し、ドラッグ後のスクロール位置を保持。端で静止したときだけナビをスクロールし、スクロールバーを見やすくしました。
- 設定上部にLanguageの選択を固定表示し、言語を切り替えても設定画面を継続します。
- 既存の有効化・設定・商品連携を引き継ぐ構成を維持しました。Windows / Unity 2022.3.22f1で使い捨てデータによる確認を行っています。Unity 6・macOSの実機動作は未確認です。

Changes from 1.0.2.

- Start saved My List imports sooner in a new Project, reusing package information already scanned on the same PC.

- Search and choose unitypackages inside a product, then import them in the displayed order, with an optional Unity dialog per file. Open in Explorer remains available for README and ZIP files.
- Add PC-user-shared My Lists and Favorites containing products, file choices and order, for batch import into the current Project.
- Put selected Material-name packages first within a product for new selections, while preserving explicit and existing saved order.
- Drag Library cards or rows onto existing navigation lists; prevent duplicate membership and unintended favorite removal. Keep button alternatives at narrow widths.
- Clarify progress, pause/cancel-unstarted/resume, failure and unrecorded-outcome recovery. Store queue/completion records per Project without automatic restart after reopening Unity.
- Preserve scroll position after a drop, require a brief edge hold for navigation scrolling, improve scrollbar visibility and narrow layouts, and keep Language fixed at the top of Settings.
- Retain existing activation, settings and product links. Disposable-data verification used Windows / Unity 2022.3.22f1. Unity 6 and macOS runtime behavior remain unverified.

## 1.0.2 — 修正と操作改善 / Fixes and navigation

- 狭幅で詳細の移動ボタンが折り返すと、後続のボタンや状態表示と重なる問題を修正。幅に応じた縦並びと通常幅の横並びを切り替え、固定ヘッダーと下部スクロールを維持。
- 「設定」に取り込みの紐づけ確認と、処理終了後の自動連携の要確認の項目数を表示し、設定から各一覧を開けるようにしました。
- 要確認一覧から、対象商品や選択中の候補の商品詳細へ移るボタンを追加。閲覧だけでは解決・紐づけを行いません。対象が隠れる場合だけ検索・絞り込みを解除し、選択した行を表示します。

English: fixes overlapping detail actions and status at narrow widths while preserving the fixed header and lower scroll area. Settings now counts unresolved import-review items and issues from completed Auto link operations, with entrances to both lists. Review rows can open the target or chosen candidate product without resolving or confirming links. Search and filters are cleared only when needed to reveal the selected product.


## 1.0.1 — 修正 / Fixes

- Unityの取り込み完了通知が項目通知より先に届く場合も、取り込み項目を保持して商品照合へ渡すよう修正。
- メイン画面の「取り消す」ボタンを非表示にしました。設定内の自動連携画面からの取消と既存の保存形式は維持します。

English: preserves imported item paths when Unity reports package completion before the item notification, allowing product matching to run. Removed Undo from the main window; Undo in Auto link settings and existing stored data remain compatible.

## 1.0.0 — 正式版 / Release

- フォルダー登録ファイルが破損・空・不正な型・読取不可の場合、空の登録として上書きせず停止。原因と復旧手順、登録データの再読込を追加。
- 通常リンク、確認対象の追加・確定・却下、フォルダー登録・削除、一括リンク・取消を、保存成功後にメモリーへ反映。確認対象の確定とリンク保存を1回の保存に統合し、失敗した変更が後続の保存へ混入しないよう修正。
- 有効化済みの状態と同じPC・OSユーザーでの保存範囲を明確化。取り込み後の自動処理は商品を照合できた場合であることを案内。

English: folder registration read errors now preserve the original file and stop writes, with recovery guidance and reload. Link, pending-review and folder mutations publish cached changes only after successful saving; resolving a review saves its links and removal together. Activation wording now states the same-PC/OS-user scope, and import guidance explains that automatic linking requires a product match.
