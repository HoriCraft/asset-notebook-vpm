# アセットノート / Asset Notebook

**1.3.0**

BOOTH Library Manager（BLM）のカタログをUnityで検索し、選んだunitypackageを順番にインポートするツールです。マイリストに商品・ファイル選択・順番をまとめ、現在のプロジェクトで繰り返し使えます。

使い方は [日本語マニュアル](Documentation~/manual-ja.html) / [English manual](Documentation~/manual-en.html)。1.0.2からの更新も案内しています。

## 初回と更新

1. 購入者向け案内に従い、VCC / ALCOMで対象プロジェクトへ追加します。更新は同じプロジェクトのパッケージを更新してください。
2. Unityの **HoriCraft → Asset Notebook** を開きます。有効化を求められた場合は、購入ページの解除キーZIPを展開して START_HERE.html を開き、「解除キーをコピー」→Unityの「解除キーを貼り付け」を使います。
3. BLMでダウンロード・展開した商品を読み込みます。見つからなければ「data.db を選ぶ…」または「標準の場所から読み直す」。商品の保存場所は「設定」で確認できます。
4. 商品詳細の「インポート」からファイルを選び、「Nファイルをインポート」を押します。開くだけでは始まりません。READMEやZIPは「エクスプローラーで開く」で確認できます。

更新前にはプロジェクトをバックアップしてください。通常は既存の有効化・設定・連携を引き継ぎます。1.0.2で取り込んだAssetsは完了記録不足で状態を判定できない場合がありますが、それだけで再インポートする必要はありません。「導入済みアセットを商品と照合」で照合できます。

## マイリストと保存範囲

- **マイリスト・お気に入りは、このPCの同じOSユーザーで共通**です。複数プロジェクトで使えますが、別PCへの自動同期はありません。
- **Assets、連携、インポート待機・完了記録はプロジェクトごと**です。開始前に「インポート先」を確認してください。
- ナビの「＋」でリストを作り、「商品を追加」または商品詳細の「マイリストに追加」で登録します。左ナビが常時見える幅ではカード・リスト行のドラッグでも追加できます。狭幅は既存のボタンや★を使います。
- 必要なファイルにチェックし、「N商品をインポート」でまとめてインポートします。商品順は上下ボタン、ファイル全体の順番は「リストの操作」→「全体のインポート順」で調整します。

## 選択と順番

新しい商品をリストに追加するときは、確認済みの単一候補、または同じ用途の純粋な版違いだけなら候補を自動選択します。アバター別・お試し版などは自分で選びます。

新しい／未設定のファイル選択では、ファイル名に独立した Material / Materials / MaterialPackage / マテリアル を含むものを、同じ商品内で先にします。未選択のファイルを追加せず、商品間の順番も変えません。手動の順番・保存済みマイリスト・開始済み待機順を優先します。詳しい条件と除外例はマニュアルを参照してください。

## 進行・設定

進行状況は画面下端から開きます。「このファイルの後で一時停止」→「再開」で続行できます。「未開始分を中止」は取り込んだAssetsを元に戻しません。失敗や結果未記録では、プロジェクトを確認して再試行かスキップを選びます。Unity再起動後・一時停止中の追加では自動再開しません。

設定上部の **Language / 表示言語**（英語では **Language**）で日本語 / Englishを選べます。有効化は同じPC・OSユーザーで共通で、解除すると他のプロジェクトでも利用できなくなります。

## 対応環境

Windows / Unity 2022.3が対象です。Unity 2022.3.22f1で使い捨てデータによるインポート・復帰・狭幅操作を確認しています。Unity 6・macOSの実機動作は未確認です。BLMのスマートリストは対象外です。

BLMの管理データは読み取り専用です。BOOTH・pixiv・BLMの公認ツールではありません。利用条件は [LICENSE.md](LICENSE.md) を確認してください。

## English

Asset Notebook searches your BLM catalog in Unity and imports selected unitypackages in order. My Lists keep products, file choices and order together. Follow the [English manual](Documentation~/manual-en.html) for first use and the update from 1.0.2.

- Add or update the package in VCC / ALCOM using the purchaser instructions, then open **HoriCraft → Asset Notebook**. Activate with the purchaser key only when requested. Existing activation and settings normally carry over.
- Choose **Import**, select the files and use **Import N files**. Use **Open in Explorer** for README and ZIP files. Opening the picker does not start an import.
- **My Lists and Favorites are shared by the same OS user on this PC.** Assets, links, pending imports and completion records belong to each Project. There is no automatic sync to another PC.
- Use **Add products**, **Add to My Lists** or the star. At wide widths, drag a card or list row onto an existing navigation list. At narrow widths use the buttons instead. Check files and select **Import N products**. Use arrows and **List details → Overall import order** to adjust order.
- New membership may select a verified single candidate or a pure version alternative. Choose avatar/trial alternatives yourself. New/unconfigured selections put selected Material-name packages first within each product. Explicit order, existing saved lists and queued imports take priority; the manual gives matching rules and exclusions.
- Open progress from the bottom strip. **Pause after this file → Resume** continues later work. **Cancel unstarted files** does not undo Assets. Review failures and unrecorded outcomes before retrying or skipping. Restarting Unity or adding to a paused queue does not resume automatically.
- The fixed **Language** dropdown is at the top of **Settings**. Activation is shared by this OS user on this PC; removing it affects the user's other Projects.

Target: Windows / Unity 2022.3. Disposable-data checks used Unity 2022.3.22f1; Unity 6 and macOS runtime behavior are unverified. BLM smart lists are not supported. BLM data is read only. This tool is unofficial; see [LICENSE.md](LICENSE.md).
