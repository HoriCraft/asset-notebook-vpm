# Changelog

## 1.0.2 — 修正と操作改善 / Fixes and navigation

- 狭幅で詳細の移動ボタンが折り返すと、後続のボタンや状態表示と重なる問題を修正。幅に応じた縦並びと通常幅の横並びを切り替え、固定ヘッダーと下部スクロールを維持。
- 「設定」に取り込みの紐づけ確認と、処理終了後の自動連携の要確認の項目数を表示し、設定から各一覧を開けるようにしました。
- 要確認一覧から、対象商品や選択中の候補の商品詳細へ移るボタンを追加。閲覧だけでは解決・紐づけを行いません。対象が隠れる場合だけ検索・絞り込みを解除し、選択した行を表示します。

English: fixes overlapping detail actions and status at narrow widths while preserving the fixed header and lower scroll area. Settings now counts unresolved import-review items and issues from completed Auto link operations, with entrances to both lists. Review rows can open the target or chosen candidate product without resolving or confirming links. Search and filters are cleared only when needed to reveal the selected product.


## 1.0.1 — 修正 / Fixes

- Unityの取り込み完了通知が項目通知より先に届く場合も、取り込み項目を保持して商品照合へ渡すよう修正。
- メイン画面の「取り消す」ボタンを非表示にしました。設定内の自動連携画面からの取消と既存の保存形式は維持します。

English: preserves imported item paths when Unity reports package completion before the item notification, allowing product matching to run. Removed Undo from the main window; Undo in Auto link settings and existing stored data remain compatible.

## 1.0.0 — 正式版 / Release

- フォルダー登録ファイルが破損・空・不正な型・読取不可の場合、空の登録として上書きせず停止。原因と復旧手順、登録データの再読込を追加。
- 通常リンク、確認対象の追加・確定・却下、フォルダー登録・削除、一括リンク・取消を、保存成功後にメモリーへ反映。確認対象の確定とリンク保存を1回の保存に統合し、失敗した変更が後続の保存へ混入しないよう修正。
- 有効化済みの状態と同じPC・OSユーザーでの保存範囲を明確化。取り込み後の自動処理は商品を照合できた場合であることを案内。

English: folder registration read errors now preserve the original file and stop writes, with recovery guidance and reload. Link, pending-review and folder mutations publish cached changes only after successful saving; resolving a review saves its links and removal together. Activation wording now states the same-PC/OS-user scope, and import guidance explains that automatic linking requires a product match.

## 1.0.0-candidate.6 — テスト版 / Test version

- 表示名を「アセットノート / Asset Notebook」へ変更。package ID、assembly、namespace、保存先、既存meta、解除キー方式を維持。
- ワンボタンの自動連携、進捗・中止・続行・失敗理由・再試行・前回分の取消を追加。画像保存queueの失敗時に状態を先行させないよう修正。
- 固定の画像・商品名ヘッダーと下部スクロール、フィルタの重ね表示、部分一致タグ入力、日英の明示切替と選択保持、Assets移動先の集約を追加。
- 共通の版表示、manifestとDLLの版照合、最小限の問い合わせ情報コピーを追加。
- BOOTH Library Managerデータ選択を設定へまとめ、取り込み商品の紐づけ確認に理由と操作の説明を表示。

English: renamed the visible product, added one-button automatic linking with progress, stop/continue/retry/undo, improved queue failure handling, fixed detail headers and filters, persistent language selection, grouped Assets navigation, package-version checks and minimal support information. Existing identities, paths and activation configuration remain unchanged. This is a test version.

Earlier public candidates remain immutable. Their original changelogs and licenses are retained in the corresponding packages. The MIT grants for preview.1–.5 remain unchanged.