# アセットノート / Asset Notebook

1.0.1 — 正式版 / Release

BOOTH Library Manager の保存済み商品を Unity Editor で探し、導入済みアセットと商品を結び付ける非公式ツールです。BOOTH、pixiv、BOOTH Library Managerの公認製品ではありません。Windows / Unity 2022.3向け。Unity 6は未検証です。data.db・購入アセット・解除キーは同梱していません。

## 使い方

1. `HoriCraft > Asset Notebook` または `Window > HoriCraft > Asset Notebook` を開き、購入者向け案内に従って有効化します。有効化情報は同じPC・OSユーザーのUnityプロジェクトで共有されます。
2. 右上「設定」からBOOTH Library Managerのデータと、自動連携の追加保存先を確認できます。「更新」は商品一覧を読み直します。
3. 商品名などで検索し、「フィルタ」で条件を入力します。タグはBLM・独自タグの部分一致で、大文字小文字を区別しません。入力は即時反映されます。Languageで日本語/Englishを明示選択すると、同じOSユーザーのUnity Editorでその選択を保持します。
4. 右上の「自動連携」を1回押すと、指定済み保存先を調査し、安全に確定できる既存Assetsを連携します。初回は全packageの調査が必要で、時間がかかる場合があります。フィルタに隠れた商品も対象です。中止しても保存済み読取り結果と成功したリンクを残し、「続ける」で再開できます。
5. 未読package・未接続保存先があれば自動確定を保留します。「詳細」で商品と理由を確認し、接続や元ファイルを確認して再試行します。曖昧な候補は商品詳細から手動登録します。フォルダー名だけで確定せず、既存の手動リンクと共有GUIDを保護します。
6. 設定内の自動連携画面の「取り消す」は、前回の実行で追加し、その後に手動変更していないリンクを取り消します。画像は削除しません。
7. 新しいunitypackageはUnity標準のインポート画面から取り込みます。商品を自動確定できない場合は「商品との紐づけを確認」で理由を読み、候補を選びます。Assetsへの取り込み自体は完了しています。
8. 詳細の「Assetsで開く」は紐づくフォルダーをProject欄に表示します。複数の近い位置は共通の親へまとめ、別の枝は選択肢を残します。「表示画像を差し替える」でローカルPNG/JPEGを指定できます。元商品画像や既存Assets画像は上書きしません。
9. 設定の「問い合わせ情報をコピー」は版・Unity・OS・表示言語など最小限の情報と記入欄をコピーします。キー・パス・DB・購入データ・ログは含めません。

指定した保存先の範囲で照合します。元packageを削除・書換え・自動除外しません。Unityの再コンパイルや終了で処理は止まるため、再表示後に必要に応じて自動連携を開始してください。利用条件はLICENSE.mdを確認してください。旧preview.1〜.5のMIT許諾は維持されます。

## English

Asset Notebook is an unofficial Windows / Unity 2022.3 Editor extension for browsing BOOTH Library Manager data and linking imported Assets to products. Unity 6 is unverified. Purchased assets, catalog databases and activation keys are not included.

Open `HoriCraft > Asset Notebook` (also under Window), then activate using the purchaser guide. Settings contains catalog selection, Auto link settings, license information and a minimal support-information copy action. Language explicitly selects Japanese or English and remembers your choice for the same OS user.

Press Auto link once to scan configured locations and link all safe matches, including products hidden by filters. The first scan can take time. Stop preserves completed work; Continue resumes using saved scan results. Unreadable packages or unavailable locations hold automatic linking. Details shows the affected product and reason; fix the cause and Retry. Ambiguous matches can be registered manually from the product detail. Existing manual links and shared GUIDs are preserved. Undo in Auto link settings removes unchanged links added by the last operation; saved images remain.

Use Unity's normal package importer for new packages. Unclear import matches appear under the product-link review action with explanations. Assets have already been imported. Assets navigation groups related folders without changing ownership. Thumbnail overrides use a local copy and preserve original images. Search and tag filters apply immediately. Recompilation or closing Unity stops work; start Auto link again when needed. See LICENSE.md for the applicable terms. Activation is shared across Unity projects for the same OS user on the same PC.